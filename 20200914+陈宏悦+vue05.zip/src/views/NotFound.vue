<template>
    <div>
        not found  please go to Home  404
    </div>
</template>

<script>
    export default {
        
    }
</script>

<style scoped>

</style>